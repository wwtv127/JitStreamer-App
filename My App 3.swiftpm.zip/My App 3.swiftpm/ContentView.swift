import SwiftUI
import WebKit

struct ContentView: View {
    @State var showingBottomSheet = false
    @State private var JITText = "Connecting to JitStreamer"
    @State var jitstreamerConnected: Bool = false
    @State var showError: Bool = false
    @State var errorString: String = ""
    
    var body: some View {
        NavigationStack {
            VStack {
                Image("phot")
                    .resizable()
                    .frame(width: 150, height: 150)
                
                Button("Enable JIT") {
                    showingBottomSheet.toggle()
                }
                .sheet(isPresented: $showingBottomSheet) {
                    if !showError, !jitstreamerConnected {
                        VStack {
                            Image("phot")
                                .resizable()
                                .frame(width: 150, height: 150)
                            HStack {
                                Text(JITText)
                                    .bold()
                                    .font(.title2)
                                ProgressView()
                                    .onAppear {
                                        self.JITText = "Connecting to JitStreamer"
                                        JitStreamerHandler.shared.detectIfCurrentVersion() { result, error in
                                            jitstreamerConnected = result
                                            print("hi")
                                            if !result {
                                                showError = true
                                                errorString = error ?? "Unknown Error"
                                            }
                                        }
                                    }
                            }
                        }
                    } else if jitstreamerConnected {
                        VStack {
                            
                            ScrollView {
                                VStack {
                                    Image("phot")
                                        .resizable()
                                        .frame(width: 150, height: 150)
                                    Text(JITText)
                                        .bold()
                                        .font(.title2)
                                        .onAppear {
                                            self.JITText = "JitStreamer connected Successfully!"
                                        }
                                }
                                .padding(.vertical)
                                
                                AppsListView()
                            }
                        }
                        .padding(.bottom)
                    } else {
                        VStack(spacing: 20) {
                            VStack {
                                Image("phot")
                                    .resizable()
                                    .frame(width: 150, height: 150)
                                
                                Text("Error connecting to JITStreamer")
                                    .font(.title)
                            }
                            
                            Text(errorString)
                                .font(.title3)
                        }
                    }
                }
                .foregroundColor(.white)
                .padding()
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 8))
                
                NavigationLink("Set Up", destination: WebsiteView())
                    .foregroundColor(.white)
                    .padding()
                    .buttonStyle(.borderedProminent)
                    .buttonBorderShape(.roundedRectangle(radius: 8))
                
                Button("Attach SideStore/AltStore Extension") {
                    
                }
                .foregroundColor(.white)
                .padding()
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 8))
                
                ExportView()
            }
        }
    }
}
